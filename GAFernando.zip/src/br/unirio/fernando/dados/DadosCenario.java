package br.unirio.fernando.dados;

import java.util.ArrayList;

public class DadosCenario extends ArrayList<DadosConfiguracao>
{
	private static final long serialVersionUID = 1L;

	private String cenario;

	public DadosCenario(String cenario)
	{
		super();
		this.cenario = cenario;
	}

	public String getCenario()
	{
		return cenario;
	}

	public DadosConfiguracao pegaConfiguracao(String algoritmo, int populacao)
	{
		for (DadosConfiguracao configuracao : this)
			if (configuracao.getAlgoritmo().compareTo(algoritmo) == 0 && configuracao.getPopulacao() == populacao)
				return configuracao;
		
		return null;
	}
}