package br.unirio.fernando.dados;

import java.util.ArrayList;

public class DadosConfiguracao extends ArrayList<DadosRodada>
{
	private static final long serialVersionUID = 7454048068855911866L;

	private String algoritmo;
	private int populacao;
	private int custoObservado;

	public DadosConfiguracao(String algoritmo, int populacao, int custoObservado)
	{
		this.algoritmo = algoritmo;
		this.populacao = populacao;
		this.custoObservado = custoObservado;
	}

	public String getAlgoritmo()
	{
		return algoritmo;
	}

	public int getPopulacao()
	{
		return populacao;
	}

	public int getCustoObservado()
	{
		return custoObservado;
	}
}