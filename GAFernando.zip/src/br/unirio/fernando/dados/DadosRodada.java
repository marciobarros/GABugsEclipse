package br.unirio.fernando.dados;

public class DadosRodada
{
	private int tempo;
	private int custo;
	private int makespan;

	public DadosRodada(int tempo, int custo, int makespan)
	{
		this.tempo = tempo;
		this.custo = custo;
		this.makespan = makespan;
	}

	public int getTempo()
	{
		return tempo;
	}

	public int getCusto()
	{
		return custo;
	}

	public int getMakespan()
	{
		return makespan;
	}
}