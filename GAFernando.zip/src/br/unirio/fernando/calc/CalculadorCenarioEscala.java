package br.unirio.fernando.calc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import br.unirio.fernando.config.Configuracao;
import br.unirio.fernando.dados.DadosCenario;
import br.unirio.fernando.dados.DadosConfiguracao;
import br.unirio.fernando.dados.DadosRodada;

public class CalculadorCenarioEscala
{
	private String pegaNomeArquivo(String nomeCenario, String algoritmo, int populacao)
	{
		String nomeDiretorio = Configuracao.DIRETORIO_BASE + "\\" + nomeCenario + "\\" + algoritmo + " " + populacao;
		File fileDiretorio = new File(nomeDiretorio);
		
		for (String nomeArquivo : fileDiretorio.list())
		{
			if (nomeArquivo.startsWith("resultados_" + populacao + "_200"))
				return nomeDiretorio + "\\" + nomeArquivo;
		}		
		
		return null;
	}
	
	public void carregaCenario(DadosCenario dados, String nomeCenario, String algoritmo, int populacao) throws Exception
	{
		String nomeArquivo = pegaNomeArquivo(nomeCenario, algoritmo, populacao);
		
		if (nomeArquivo == null)
			throw new Exception(nomeCenario + " " + algoritmo + populacao + ": arquivo nao encontrado");

		try
		{
			File aFile = new File(nomeArquivo);
			BufferedReader input = new BufferedReader(new FileReader(aFile));
			String line = input.readLine();
			
			if (!line.startsWith("Actual Cost = "))
			{
				input.close();
				throw new Exception(nomeCenario + " " + algoritmo + populacao + ": custo observado nao encontrado");
			}
			
			int custoObservado = Integer.parseInt(line.substring(14));
			int numeroCiclo = 0;
			
			DadosConfiguracao dc = new DadosConfiguracao(algoritmo, populacao, custoObservado);
			dados.add(dc);

			while ((line = input.readLine()) != null)
			{				
				if (!line.startsWith("Cycle "))
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": numero de ciclo nao encontrado na linha " + (numeroCiclo + 2));
				}
				
				int posicao = line.indexOf(';');
				
				if (posicao == -1)
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": primeiro ponto-e-virgula nao encontrado na linha " + (numeroCiclo + 2));
				}
				
				int cicloLinha = Integer.parseInt(line.substring(6, posicao));
				
				if (numeroCiclo != cicloLinha)
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": numero de ciclo diferente do esperado na linha " + (numeroCiclo + 2));
				}
				
				numeroCiclo++;				
				line = line.substring(posicao + 2);

				if (!line.startsWith("Time = "))
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": tempo de execucao nao encontrado na linha " + (cicloLinha + 2));
				}
				
				posicao = line.indexOf(';');
				
				if (posicao == -1)
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": segundo ponto-e-virgula nao encontrado na linha " + (cicloLinha + 2));
				}
				
				int tempo = Integer.parseInt(line.substring(7, posicao));
				line = line.substring(posicao + 2);

				if (!line.startsWith("Cost = "))
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": custo nao encontrado na linha " + (cicloLinha + 2));
				}
				
				posicao = line.indexOf(';');
				
				if (posicao == -1)
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": terceiro ponto-e-virgula nao encontrado na linha " + (cicloLinha + 2));
				}
				
				int custo = Integer.parseInt(line.substring(7, posicao));
				line = line.substring(posicao + 2);

				if (!line.startsWith("Makespan = "))
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": makespan nao encontrado na linha " + (cicloLinha + 2));
				}
				
				int makespan = Integer.parseInt(line.substring(11));

				DadosRodada dr = new DadosRodada(tempo, custo, makespan);
				dc.add(dr);
			}

			input.close();

		} catch (IOException ex)
		{
			throw new Exception(nomeCenario + " " + algoritmo + populacao + ": erro de leitura no arquivo");
		}
	}
	
	public void executa() throws Exception
	{
		List<DadosCenario> cenarios = new ArrayList<DadosCenario>();
		
		for (int i = 100; i <= 1500; i += 100)
		{
			DadosCenario dados = new DadosCenario(i + " Bugs");
			carregaCenario(dados, "Bugs " + i, "GA", 50);
			carregaCenario(dados, "Bugs " + i, "GA", 500);
			carregaCenario(dados, "Bugs " + i, "LSRR", 500);
			cenarios.add(dados);
		}

		for (int i = 100; i <= 1500; i += 100)
		{
			System.out.print("B" + i + "GA50TM" + "\t");
			System.out.print("B" + i + "GA50CS" + "\t");
			System.out.print("B" + i + "GA500TM" + "\t");
			System.out.print("B" + i + "GA500CS" + "\t");
			System.out.print("B" + i + "LSRR500TM" + "\t");
			System.out.print("B" + i + "LSRR500CS" + "\t");
		}

		System.out.println();

		for (int ciclo = 0; ciclo < 30; ciclo++)
		{
			for (int i = 100; i <= 1500; i += 100)
			{
				DadosCenario dados = cenarios.get(i / 100 - 1);
	
				DadosConfiguracao dc_ga50 = dados.pegaConfiguracao("GA", 50);
				DadosRodada dr_ga50 = dc_ga50.get(ciclo);
				System.out.print(dr_ga50.getTempo() + "\t");
				System.out.print(dr_ga50.getCusto() + "\t");
	
				DadosConfiguracao dc_ga500 = dados.pegaConfiguracao("GA", 500);
				DadosRodada dr_ga500 = dc_ga500.get(ciclo);
				System.out.print(dr_ga500.getTempo() + "\t");
				System.out.print(dr_ga500.getCusto() + "\t");
	
				DadosConfiguracao dc_ls500 = dados.pegaConfiguracao("LSRR", 500);
				DadosRodada dr_ls500 = dc_ls500.get(ciclo);
				System.out.print(dr_ls500.getTempo() + "\t");
				System.out.print(dr_ls500.getCusto() + "\t");
			}
	
			System.out.println();
		}

		System.out.println();
		System.out.println();

		for (int i = 100; i <= 1500; i += 100)
		{
			DadosCenario dados = cenarios.get(i / 100 - 1);
			DadosConfiguracao dc_ga50 = dados.pegaConfiguracao("GA", 50);
			System.out.print(dc_ga50.getCustoObservado() + "\t");
		}
	
		System.out.println();
	}
}