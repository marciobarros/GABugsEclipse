package br.unirio.fernando.calc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import br.unirio.fernando.config.Configuracao;
import br.unirio.fernando.dados.DadosCenario;
import br.unirio.fernando.dados.DadosConfiguracao;
import br.unirio.fernando.dados.DadosRodada;

public class CalculadorCenarioBasico
{
	private String pegaNomeArquivo(String nomeCenario, String algoritmo, int populacao)
	{
		String nomeDiretorio = Configuracao.DIRETORIO_BASE + "\\" + nomeCenario + "\\" + algoritmo + " " + populacao;
		File fileDiretorio = new File(nomeDiretorio);
		
		for (String nomeArquivo : fileDiretorio.list())
		{
			if (nomeArquivo.startsWith("resultados_" + algoritmo + "_" + populacao + "_200"))
				return nomeDiretorio + "\\" + nomeArquivo;
		}		
		
		return null;
	}
	
	public void carregaCenario(DadosCenario dados, String nomeCenario, String algoritmo, int populacao) throws Exception
	{
		String nomeArquivo = pegaNomeArquivo(nomeCenario, algoritmo, populacao);
		
		if (nomeArquivo == null)
			throw new Exception(nomeCenario + " " + algoritmo + populacao + ": arquivo nao encontrado");

		try
		{
			File aFile = new File(nomeArquivo);
			BufferedReader input = new BufferedReader(new FileReader(aFile));
			String line = input.readLine();
			
			if (!line.startsWith("Actual Cost = "))
			{
				input.close();
				throw new Exception(nomeCenario + " " + algoritmo + populacao + ": custo observado nao encontrado");
			}
			
			int custoObservado = Integer.parseInt(line.substring(14));
			int numeroCiclo = 0;
			
			DadosConfiguracao dc = new DadosConfiguracao(algoritmo, populacao, custoObservado);
			dados.add(dc);

			while ((line = input.readLine()) != null)
			{				
				if (!line.startsWith("Cycle "))
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": numero de ciclo nao encontrado na linha " + (numeroCiclo + 2));
				}
				
				int posicao = line.indexOf(';');
				
				if (posicao == -1)
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": primeiro ponto-e-virgula nao encontrado na linha " + (numeroCiclo + 2));
				}
				
				int cicloLinha = Integer.parseInt(line.substring(6, posicao));
				
				if (numeroCiclo != cicloLinha)
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": numero de ciclo diferente do esperado na linha " + (numeroCiclo + 2));
				}
				
				numeroCiclo++;				
				line = line.substring(posicao + 2);

				if (!line.startsWith("Time = "))
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": tempo de execucao nao encontrado na linha " + (cicloLinha + 2));
				}
				
				posicao = line.indexOf(';');
				
				if (posicao == -1)
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": segundo ponto-e-virgula nao encontrado na linha " + (cicloLinha + 2));
				}
				
				int tempo = Integer.parseInt(line.substring(7, posicao));
				line = line.substring(posicao + 2);

				if (!line.startsWith("Cost = "))
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": custo nao encontrado na linha " + (cicloLinha + 2));
				}
				
				posicao = line.indexOf(';');
				
				if (posicao == -1)
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": terceiro ponto-e-virgula nao encontrado na linha " + (cicloLinha + 2));
				}
				
				int custo = Integer.parseInt(line.substring(7, posicao));
				line = line.substring(posicao + 2);

				if (!line.startsWith("Makespan = "))
				{
					input.close();
					throw new Exception(nomeCenario + " " + algoritmo + populacao + ": makespan nao encontrado na linha " + (cicloLinha + 2));
				}
				
				int makespan = Integer.parseInt(line.substring(11));

				DadosRodada dr = new DadosRodada(tempo, custo, makespan);
				dc.add(dr);
			}

			input.close();

		} catch (IOException ex)
		{
			throw new Exception(nomeCenario + " " + algoritmo + populacao + ": erro de leitura no arquivo");
		}
	}
	
	public void executa(String nomeCenario) throws Exception
	{
		String[] algoritmos = {"GA", "LS", "LSRR" };
		int[] populacoes = {50, 100, 500, 1000};
		
		DadosCenario dados = new DadosCenario(nomeCenario);
		
		for (String algoritmo : algoritmos)
			for (int populacao : populacoes)
				carregaCenario(dados, nomeCenario, algoritmo, populacao);
		
		for (String algoritmo : algoritmos)
			for (int populacao : populacoes)
			{
				System.out.print(algoritmo + populacao + "TM" + "\t");
				System.out.print(algoritmo + populacao + "CS" + "\t");
				System.out.print(algoritmo + populacao + "MS" + "\t");
			}

		System.out.println();
		
		for (int i = 0; i < 30; i++)
		{
			for (String algoritmo : algoritmos)
			{
				for (int populacao : populacoes)
				{
					DadosConfiguracao dc = dados.pegaConfiguracao(algoritmo, populacao);
					DadosRodada dr = dc.get(i);
					System.out.print(dr.getTempo() + "\t");
					System.out.print(dr.getCusto() + "\t");
					System.out.print(dr.getMakespan() + "\t");
				}
			}

			System.out.println();
		}
	}
}