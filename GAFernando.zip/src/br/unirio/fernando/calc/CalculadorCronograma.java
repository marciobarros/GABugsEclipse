package br.unirio.fernando.calc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.StringTokenizer;

import br.unirio.fernando.config.Configuracao;

public class CalculadorCronograma
{
	private String pegaNomeArquivo(String nomeCenario, String algoritmo, int populacao, int bugs, int ciclo)
	{
		DecimalFormat nf = new DecimalFormat("00");
		String nomeDiretorio = Configuracao.DIRETORIO_BASE + "\\" + nomeCenario + "\\" + algoritmo + " " + populacao + "\\schedules\\";
		return nomeDiretorio + "SCH" + algoritmo.substring(0, 2) + "_" + populacao + "_200_" + bugs + "_" + nf.format(ciclo) + ".txt";		
	}
	
	private DadosRodada carregaCenario(String nomeCenario, String algoritmo, int populacao, int bugs, int ciclo, int dias)
	{
		String nomeArquivo = pegaNomeArquivo(nomeCenario, algoritmo, populacao, bugs, ciclo);
		
		if (nomeArquivo == null)
		{
			System.out.println(nomeCenario + " " + algoritmo + populacao + ": arquivo nao encontrado");
			return null;
		}
		
		DadosRodada dr = new DadosRodada();

		try
		{
			File aFile = new File(nomeArquivo);
			BufferedReader input = new BufferedReader(new FileReader(aFile));

			String line;
			String ultimoAutor = "";
			int tempoAutor = 0;

			while ((line = input.readLine()) != null)
			{
				if (line.length() > 0)
				{				
					StringTokenizer tokenizer = new StringTokenizer(line, ";");
					
					if (tokenizer.countTokens() == 4)
					{
						String autor = tokenizer.nextToken();
						tokenizer.nextToken();
						int tempo = Integer.parseInt(tokenizer.nextToken());
						int prioridade = Integer.parseInt(tokenizer.nextToken());
						
						if (autor.compareToIgnoreCase(ultimoAutor) != 0)
						{
							tempoAutor = 0;
							ultimoAutor = autor;
						}
						
						tempoAutor += tempo;
						
						if (tempoAutor < dias * 8)
							dr.adicionaBugsPrioridade(prioridade, 1);
					}
					else
					{
						System.out.println(nomeCenario + " " + algoritmo + populacao + ": linha mal formada");
					}
				}
			}

			input.close();

		} catch (IOException ex)
		{
			System.out.println(nomeCenario + " " + algoritmo + populacao + ": erro de leitura no arquivo");
		}
		
		return dr;
	}
	
	public void executa(String nomeCenario, int bugs, int dias)
	{
		String[] algoritmos = {"GA", "LSRR"};
		int[] populacoes = {50, 100, 500, 1000};
		
		DadosCenario dados = new DadosCenario(nomeCenario);
		
		for (String algoritmo : algoritmos)
			for (int populacao : populacoes)
				dados.add(new DadosConfiguracao(algoritmo, populacao));

		for (int ciclo = 0; ciclo < 30; ciclo++)
			for (String algoritmo : algoritmos)
				for (int populacao : populacoes)
					dados.pegaConfiguracao(algoritmo, populacao).add(carregaCenario(nomeCenario, algoritmo, populacao, bugs, ciclo, dias));
		
		for (String algoritmo : algoritmos)
			for (int populacao : populacoes)
				for (int i = 1; i <= 5; i++)
					System.out.print(algoritmo + populacao + "P" + i + "\t");

		System.out.println();

		for (int ciclo = 0; ciclo < 30; ciclo++)
		{
			for (String algoritmo : algoritmos)
				for (int populacao : populacoes)
				{
					DadosConfiguracao configuracao = dados.pegaConfiguracao(algoritmo, populacao);
					
					for (int i = 1; i <= 5; i++)
						System.out.print(configuracao.get(ciclo).getBugsPrioridade(i) + "\t");
				}

			System.out.println();
		}
	}
}

class DadosCenario extends ArrayList<DadosConfiguracao>
{
	private static final long serialVersionUID = 1L;

	private String cenario;

	public DadosCenario(String cenario)
	{
		super();
		this.cenario = cenario;
	}

	public String getCenario()
	{
		return cenario;
	}

	public DadosConfiguracao pegaConfiguracao(String algoritmo, int populacao)
	{
		for (DadosConfiguracao configuracao : this)
			if (configuracao.getAlgoritmo().compareTo(algoritmo) == 0 && configuracao.getPopulacao() == populacao)
				return configuracao;
		
		return null;
	}
}

class DadosConfiguracao extends ArrayList<DadosRodada>
{
	private static final long serialVersionUID = -5156357655111604160L;
	
	private String algoritmo;
	private int populacao;

	public DadosConfiguracao(String algoritmo, int populacao)
	{
		super();
		this.algoritmo = algoritmo;
		this.populacao = populacao;
	}

	public String getAlgoritmo()
	{
		return algoritmo;
	}

	public int getPopulacao()
	{
		return populacao;
	}
}

class DadosRodada
{
	private int[] bugsPrioridade;
	
	public DadosRodada()
	{
		this.bugsPrioridade = new int[5];
	}
	
	public int getBugsPrioridade(int prioridade)
	{
		return bugsPrioridade[prioridade-1];
	}
	
	public void adicionaBugsPrioridade(int prioridade, int bugs)
	{
		this.bugsPrioridade[prioridade-1] += bugs;
	}
}