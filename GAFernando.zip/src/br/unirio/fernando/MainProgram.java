package br.unirio.fernando;

import br.unirio.fernando.calc.CalculadorCronograma;

public class MainProgram
{
	public static void main(String[] args) throws Exception
	{
		//new CalculadorCenarioBasico().executa("Bugs Cenario 1");
		//new CalculadorCenarioBasico().executa("Bugs Cenario 2");
		//new CalculadorCenarioEscala().executa();
		new CalculadorCronograma().executa("Bugs Cenario 1", 134, 10);
		//new CalculadorCronograma().executa("Bugs Cenario 2", 1529, 11);
	}
}