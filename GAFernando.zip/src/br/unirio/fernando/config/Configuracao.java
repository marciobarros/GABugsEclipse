package br.unirio.fernando.config;

public class Configuracao 
{
	public static String DIRETORIO_BASE = "\\Users\\Marcio\\Desktop\\Resultados Pesquisa\\Resultados Bugs Fernando";
}